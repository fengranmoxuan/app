/**
 * Created by Administrator on 2017/3/31.
 */
window.onresize=window.onload=function(){
    document.getElementsByTagName("html")[0].style.fontSize=document.documentElement.clientWidth/15+"px";

}